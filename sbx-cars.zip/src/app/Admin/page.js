import AdminHomePage from "./Home/page";

export default function Home() {
  return (
    <div>
      <AdminHomePage/>
    </div>
  );
}