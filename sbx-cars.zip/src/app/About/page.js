import FirstSection from "./FirstSection";
import WhyCarBuyDirect from "./WhyCarBuyDirect";

export default function About(){
    return(
        <div>
            <FirstSection/>
            <WhyCarBuyDirect/>
        </div>
    )
}