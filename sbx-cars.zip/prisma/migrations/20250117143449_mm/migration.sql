-- AlterTable
ALTER TABLE `brand` MODIFY `image` TEXT NOT NULL;
