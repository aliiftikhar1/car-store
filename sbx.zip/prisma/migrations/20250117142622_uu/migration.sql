-- AlterTable
ALTER TABLE `brand` MODIFY `image` LONGTEXT NOT NULL;
