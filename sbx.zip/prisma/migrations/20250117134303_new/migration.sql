-- AlterTable
ALTER TABLE `carimage` MODIFY `url` LONGTEXT NOT NULL;

-- AlterTable
ALTER TABLE `user` MODIFY `image` LONGTEXT NULL;
