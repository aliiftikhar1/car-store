/** @type {import('next').NextConfig} */
const nextConfig = {
  // output: 'export',
   images: {
    domains: ['46.202.130.158','localhost','www.getcarbuydirect.com'], // Add the IP address here
  },
};
  
  export default nextConfig
