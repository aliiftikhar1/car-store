import FAQSection from './FAQSection'
export default function FAQ(){
    return(
        <div>
            <FAQSection />
        </div>
    )
}