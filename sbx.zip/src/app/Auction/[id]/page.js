import Car from "./MainPage";

export default function CarHomePage(){
  return(
    <Car/>
  )
}