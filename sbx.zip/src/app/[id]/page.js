import MyProfile from "./MainPage";

export default function ProfileHomePage(){
  return(
    <MyProfile/>
  )
}